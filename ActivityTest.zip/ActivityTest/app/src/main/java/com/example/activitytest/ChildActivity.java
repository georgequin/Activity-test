package com.example.activitytest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ChildActivity extends AppCompatActivity {

    TextView defaultText;
    Button Submit;
    EditText InputField;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_child);

        defaultText = findViewById(R.id.default_text);
        Submit = findViewById(R.id.submit_button);
        InputField = findViewById(R.id.input);

        String InputString = InputField.getText().toString();

        Submit.setOnClickListener((v)->{
            String URL ="http://";
            OpenWebPage(URL + InputString);
            Toast.makeText(this, "Make Search", Toast.LENGTH_SHORT).show();

        });

        Intent IntentThatStartedThisActivity = getIntent();
        if (IntentThatStartedThisActivity.hasExtra(Intent.EXTRA_TEXT)){
            String textEntered = IntentThatStartedThisActivity.getStringExtra(Intent.EXTRA_TEXT);
            defaultText.setText(textEntered);
        }
    }

    private void OpenWebPage(String url){
        Uri webpage = Uri.parse(url);
        Intent intent1 = new Intent(Intent.ACTION_VIEW);
        intent1.setData(webpage);
        if (intent1.resolveActivity(getPackageManager()) != null){
            startActivity(intent1);
        }else {
            Toast.makeText(this, "No Available Application", Toast.LENGTH_SHORT).show();
        }
    }
}
