package com.example.activitytest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;

public class mapActivity extends AppCompatActivity {

    Button SubmitButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        SubmitButton = findViewById(R.id.submit_map);

        SubmitButton.setOnClickListener((view) -> {
            String geoAddress = "1600 Amphitheatre Parkway, CA";
            showMap(geoAddress);
        });
    }

    public void  showMap(String geoAddress){
        Uri.Builder builder = new Uri.Builder();
        builder.scheme("geo").path("0,0").query(geoAddress);
        Uri AdressBuilder = builder.build();

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(AdressBuilder);

        if (intent.resolveActivity(getPackageManager()) != null){
            startActivity(intent);
        }
    }
}
