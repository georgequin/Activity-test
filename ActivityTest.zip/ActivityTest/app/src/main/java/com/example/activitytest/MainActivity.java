package com.example.activitytest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText input;
    Button SearchButton, MapButton, ShareButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        SearchButton = findViewById(R.id.network_button);
        MapButton = findViewById(R.id.map_button);
        ShareButton = findViewById(R.id.Shard_button);




        SearchButton.setOnClickListener((view) ->{
//            String data = input.getText().toString();
            Toast.makeText(this, "Start Web Activity", Toast.LENGTH_SHORT).show();
            Context context = MainActivity.this;
            Class DestinationActivity = ChildActivity.class;
            Intent intent = new Intent(context, DestinationActivity);
            //intent.putExtra(Intent.EXTRA_TEXT, data);

            startActivity(intent);

        });

        MapButton.setOnClickListener((view) -> {
            Toast.makeText(this, "Open map Activity", Toast.LENGTH_SHORT).show();
            Context context = MainActivity.this;
            Class DestinationActivity = mapActivity.class;
            Intent intent = new Intent(context, DestinationActivity);

            startActivity(intent);

        });

        ShareButton.setOnClickListener((view )->{
            Toast.makeText(this, "Open share Activity", Toast.LENGTH_SHORT).show();
            Context context = MainActivity.this;
            Class DestinationActivity = ShareActivity.class;
            Intent intent = new Intent(context, DestinationActivity);

            startActivity(intent);
        } );

    }



}
