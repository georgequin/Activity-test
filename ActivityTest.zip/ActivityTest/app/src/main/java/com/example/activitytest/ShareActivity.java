package com.example.activitytest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ShareCompat;

import android.os.Bundle;
import android.widget.Button;

public class ShareActivity extends AppCompatActivity {

    Button ShareButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share);

        ShareButton = findViewById(R.id.share_button);

        ShareButton.setOnClickListener((view) ->{

            String TextToShare = "hey hey";
            ShareIntent(TextToShare);
        } );
    }

    public  void ShareIntent(String TextToShare){
        String MimeType = "text/plain";
        String title = "Learning to share";

        ShareCompat.IntentBuilder.from(this).setChooserTitle(title).setType(MimeType).setText(TextToShare);
    }
}
